 package com.cse.buffalo.twittertrend;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import com.cse.buffalo.twittertrend.Main.TwitterTrendCounter;

public class SSPReducer extends Reducer<Text, Text, Text, Text> {

	public void reduce(Text _key, Iterable<Text> values, Context context)
			throws IOException, InterruptedException {
		// process values
		String nodeStructure="";
		int lowest=Integer.MAX_VALUE;
		int inititalDistance=0;
		System.out.println("\nIn key. Key="+_key);
		for (Text val : values) {
			System.out.println("input to reducer:"+val.toString());
			String[] strMapperOutput=val.toString().split("\\s+");
			switch(strMapperOutput[0].toLowerCase()){
			case "node":
				nodeStructure=strMapperOutput[3];
				inititalDistance=Integer.parseInt(strMapperOutput[2]);
				break;
			case "value":
				int distance=Integer.parseInt(strMapperOutput[1]);
				lowest=Math.min(distance, lowest);
				break;
			default:
				break;
			}
		}
		if(inititalDistance!=lowest){
			context.getCounter(TwitterTrendCounter.SSPCounter).increment(1);
		}
		context.write(_key, new Text(lowest+" "+nodeStructure));
	}

}
