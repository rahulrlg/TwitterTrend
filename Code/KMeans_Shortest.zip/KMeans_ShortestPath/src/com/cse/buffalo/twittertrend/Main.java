package com.cse.buffalo.twittertrend;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Counter;
import org.apache.hadoop.mapreduce.Counters;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class Main {
	static int counter=0;
	static String CENTROID_FILENAME="/input/centroid.txt";
	static String OUTPUT_FILENAME = "/part-r-00000";
	static String input="/KMeansInput";
	static String output="/KMeansOutput"+System.nanoTime();
	static String modifiedInput=output;
	public enum TwitterTrendCounter {
		SSPCounter,
		KMeansCounter;
	}
	
	public static void main(String[] args) throws Exception {
		Main objKMeansDriver=new Main();
		objKMeansDriver.getKMeans();
		objKMeansDriver.getShortestPath();
	}
	
	
	private void getShortestPath()
	{
		
		String inFile="/SSPInput";
		int counter=0;
		String outPath="/SSPOutput" + System.nanoTime()+"_"+counter;
		String outFile="/part-r-00000";
		try{
			while(true){
				
				Configuration conf=new Configuration();
				Job job=Job.getInstance(conf, "ShortestPath");
				job.setJarByClass(com.cse.buffalo.twittertrend.Main.class);
				// TODO: specify a mapper
				job.setMapperClass(SSPMapper.class);
				// TODO: specify a reducer
				job.setReducerClass(SSPReducer.class);

				// TODO: specify output types
				job.setOutputKeyClass(Text.class);
				job.setOutputValueClass(Text.class);
				FileInputFormat.setInputPaths(job, new Path(inFile));
				FileOutputFormat.setOutputPath(job, new Path(outPath));
				if (!job.waitForCompletion(true))
					return;
				
				Counters counters=job.getCounters();
				Counter sspCounter=counters.findCounter(TwitterTrendCounter.SSPCounter);
				if(sspCounter.getValue()==0){
					break;
				}
				counter++;
				inFile=outPath+outFile;
				outPath="/SSPOutput"+System.nanoTime()+"_"+counter;
			}
			
		}
		catch(ClassNotFoundException ex){
			System.err.println("Error in getShotestPath().Message:"+ex);
		}
		catch(InterruptedException ex){
			System.err.println("Error in getShotestPath().Message:"+ex);
		}
		catch(IOException ex){
			System.err.println("Error in getShotestPath().Message:"+ex);
		}
	}
	
	private void getKMeans() throws Exception
	{
		boolean iterateFlag=true;
		while(true){
		Configuration conf = new Configuration();
		deleteFolder(conf,output);
		Main objDriver =new Main();
		/*List<Double> lInitialCentres=new ArrayList<Double>();
		for(int i=1;i<=3;i++)
		{
			lInitialCentres.add(Math.random()*50*i + i);
		}
		objDriver.updateCentroid(conf, lInitialCentres);
		 */	
		Job job = Job.getInstance(conf, "JobName");
		
		job.setJarByClass(com.cse.buffalo.twittertrend.Main.class);
		// TODO: specify a mapper
		job.setMapperClass(KMeansMapper.class);
		// TODO: specify a reducer
		job.setReducerClass(KMeansReducer.class);

		// TODO: specify output types
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);

		// TODO: specify input and output DIRECTORIES (not files)
		FileInputFormat.setInputPaths(job, new Path(Util.getInputPath()));
		
			if(counter==0){
				job.addFileToClassPath(new Path(CENTROID_FILENAME)); //Add centroid file to cache to be accessed globally for all mapper.
			}
			else
			{
				job.addFileToClassPath(new Path(modifiedInput+OUTPUT_FILENAME)); 
			}
			
			
			FileOutputFormat.setOutputPath(job, new Path(output));		
			if (!job.waitForCompletion(true))
				return;
			
			List<Double> lCentres=objDriver.getOldCentroids(conf);
			List<Double> lNewCentres=objDriver.getNewCentroids(conf);
			Collections.sort(lCentres);
			Collections.sort(lNewCentres);
			Iterator<Double> it = lCentres.iterator();
			for(double dblNewCentre:lNewCentres)
			{
				double oldCentre=it.next();
				if(Math.abs(oldCentre-dblNewCentre)==0){
					iterateFlag=false;
				}
				else
				{
					iterateFlag=true;
					break;
				}
			}
			if(!iterateFlag){
				break;
			}
			counter++;
			modifiedInput=output;
			output="/KMeansOutput"+System.nanoTime();
			//objDriver.updateCentroid(conf,lNewCentres);
			
		}
	}
	private List<Double> getOldCentroids(Configuration conf)
	{
		List<Double> lCentres=new ArrayList<Double>();
		String path="";
		try{
			if(counter==0){
				path=CENTROID_FILENAME;
			}
			else
			{
				path=modifiedInput+OUTPUT_FILENAME;
			}
			Path pthCentroidFile=new Path(path);
			FileSystem fs =FileSystem.get(conf);
			BufferedReader reader=new BufferedReader(new InputStreamReader(fs.open(pthCentroidFile)));
			String line="";
			while((line=reader.readLine())!=null){
				
					String[] centre=line.split("\t");
					lCentres.add(Double.parseDouble(centre[0]));
			}
			reader.close();
		}
		catch(IOException ex)
		{
			System.err.println("Error in Main::getOldCentroids(). Message:"+ex);
		}
		return lCentres;
	}
	
	private List<Double> getNewCentroids(Configuration conf)
	{
		List<Double> lCentres=new ArrayList<Double>();
		try{
			Path pthOutputFile=new Path(output+OUTPUT_FILENAME);
			FileSystem fs =FileSystem.get(conf);
			BufferedReader reader=new BufferedReader(new InputStreamReader(fs.open(pthOutputFile)));
			String line="";
			while((line=reader.readLine())!=null){
				String[] centre=line.split("\t");
				lCentres.add(Double.parseDouble(centre[0]));
			}
			reader.close();
		}
		catch(IOException ex)
		{
			System.err.println("Error in Main::getNewCentroids(). Message:"+ex);
		}
		return lCentres;
	}
	private static void deleteFolder(Configuration conf, String folderPath ) throws IOException {
		FileSystem fs = FileSystem.get(conf);
		Path path = new Path(folderPath);
		if(fs.exists(path)) {
			fs.delete(path,true);
		}
	}
}
