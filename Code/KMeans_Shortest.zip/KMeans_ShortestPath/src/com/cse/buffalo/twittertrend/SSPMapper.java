package com.cse.buffalo.twittertrend;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class SSPMapper extends Mapper<LongWritable, Text, Text, Text> {

	public void map(LongWritable ikey, Text ivalue, Context context)
			throws IOException, InterruptedException {
		System.out.println("Incoming value in mapper"+ivalue);
		
		if(!ivalue.toString().trim().equals("")){
			String[] strIncomingValue=ivalue.toString().split("\\s+");
			if(strIncomingValue.length>0){
				int distance=Integer.parseInt(strIncomingValue[1])+1;
				String[] strAdjacencyList=strIncomingValue[2].split(":");
				for(int i=0;i<strAdjacencyList.length;i++)
				{
					System.out.println("Adj List "+strAdjacencyList[i]);
					context.write(new Text(strAdjacencyList[i]), new Text("Value "+distance));
				}
				context.write(new Text(strIncomingValue[0]), new Text("Value "+strIncomingValue[1]));
				System.out.println("In Mapper. coming line:"+ivalue);
				context.write(new Text(strIncomingValue[0]), new Text("Node "+ivalue));
			}
		}
	}
}
