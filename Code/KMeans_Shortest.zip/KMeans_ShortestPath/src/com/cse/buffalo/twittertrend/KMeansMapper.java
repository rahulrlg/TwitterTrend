package com.cse.buffalo.twittertrend;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

//KMeansMapper figures out the most suitable centroid value for given data and emit as output.
public class KMeansMapper extends Mapper<LongWritable, Text, Text, Text> {
	private List<Double> lstCentre =new ArrayList<Double>();

	public void map(LongWritable ikey, Text ivalue, Context context)
			throws IOException, InterruptedException {
		System.out.println("coming value:"+ivalue);
		if(!ivalue.toString().contains("^") || ivalue.toString().trim().equals(""))
		{
			return;
		}
		String[] strLine=ivalue.toString().split("\\^");
		if(!(strLine.length>1)){
			return;
		}
		System.out.println("coming value  length:"+strLine.length);
		double currDifference,prevfDiff,minValue=Double.MAX_VALUE;
		prevfDiff=Double.MAX_VALUE;
		try {
			getCentroids(context); // Add centres to private variables lstCentre
		}
		catch(IOException ex)
		{
			System.err.println("Error in KMeansMapper::map().Message:"+ex);
		}
		Iterator<Double> it=lstCentre.iterator();
		while(it.hasNext())
		{
			double centre=it.next();
			currDifference=Math.abs(centre-Double.parseDouble(strLine[1]));
			if(currDifference<prevfDiff)
			{
				minValue=centre;
				prevfDiff=currDifference;
			}
			
		}
		//context.write(new Text(String.valueOf(minValue)), new Text(String.valueOf(strLine[1])));
		context.write(new Text(String.valueOf(minValue)), ivalue);
	}
	private void getCentroids(Context context) throws IOException
	{
		Path[] pthCachedFile=context.getFileClassPaths();
		FileSystem fs =FileSystem.get(context.getConfiguration());
		BufferedReader reader=new BufferedReader(new InputStreamReader(fs.open(pthCachedFile[0])));
		String line="";
		while((line=reader.readLine())!=null){
			String[] centre=line.split("\t");
			lstCentre.add(Double.parseDouble(centre[0]));
			//lstCentre.add(Double.parseDouble(line));
		}
		reader.close();
	}

}
