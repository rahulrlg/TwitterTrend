package com.cse.buffalo.twittertrend;

public class Util {
	private static String strInputPath="/KMeansInput";
	private static String strOutputPath="/KMeansOutput";
	
	private static String strSSPInputPath="/SSPInput";
	private static String strSSPOutputPath="/SSPOutput";
	
	public static String getInputPath()
	{
		return strInputPath;
	}
	
	public static String getOutputPath()
	{
		return strOutputPath;
	}
	
	
	public static String getSSPInputPath()
	{
		return strSSPInputPath;
	}
	
	public static String getSSPOutputPath()
	{
		return strSSPOutputPath;
	}
	
}
