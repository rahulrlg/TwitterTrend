package com.cse.buffalo.twittertrend;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import com.cse.buffalo.twittertrend.Main.TwitterTrendCounter;

public class KMeansReducer extends Reducer<Text, Text, Text, Text> {

	public void reduce(Text _key, Iterable<Text> values, Context context)
			throws IOException, InterruptedException {
		// process values
		String delimeter=";";
		double sum=0,avg;
		int counter=0;
		StringBuilder sb=new StringBuilder();
		for (Text val : values) {
			sum+=Double.parseDouble(val.toString().split("\\^")[1]);
			sb.append(val.toString()+delimeter);
			counter++;
		}
		avg=sum/counter;
		if(!(_key.toString().equals(String.valueOf(avg)))){
			context.getCounter(TwitterTrendCounter.KMeansCounter).increment(1);
		}
		context.write(new Text(String.valueOf(avg)),new Text(sb.toString()));
	}

}
