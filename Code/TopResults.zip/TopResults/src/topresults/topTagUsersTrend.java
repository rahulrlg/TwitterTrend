package topresults;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;


public class topTagUsersTrend {

	public static void main(String[] args) throws FileNotFoundException,IOException {
		//below are the file paths that needs to be chaged if required
		FileReader cleanWcSort = new FileReader("./data/cleanWcSort.txt");
		File topHashTags = new File("./data/hashTags.txt");	
		File topUsers = new File("./data/users.txt");	
		File trends = new File("./data/trends.txt");	
		BufferedWriter bw = null;
		FileWriter fw = null;
		if (!topHashTags.exists()) {
			topHashTags.createNewFile();
		}
		if (!topUsers.exists()) {
			topUsers.createNewFile();
		}
		int hashCount=0;
		int userCount=0;
		int trendsCount=0;
		BufferedReader reader = new BufferedReader(cleanWcSort);
		String line="";
		while ((line=reader.readLine())!=null) {
				if(line.contains("#")){
					hashCount++;
					if(hashCount<50){
						fw = new FileWriter(topHashTags.getAbsoluteFile(),true);
						bw = new BufferedWriter(fw);
						bw.write(line+"\n");	
						bw.close();
					}
				}
				else if(line.contains("@")){
					userCount++;
					if(userCount<50){
						fw = new FileWriter(topUsers.getAbsoluteFile(),true);
						bw = new BufferedWriter(fw);
						bw.write(line+"\n");	
						bw.close();
					}
				}
				trendsCount++;
				if(trendsCount<50){
					fw = new FileWriter(trends.getAbsoluteFile(),true);
					bw = new BufferedWriter(fw);
					bw.write(line+"\n");	
					bw.close();
				}
				//gets the top 50 hash,user and trends and ignores the rest
				if(userCount>=50 && hashCount>=50 && trendsCount>=50){
					break;
				}
		} 
	}		
}

