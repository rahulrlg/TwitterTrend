package stripes;
import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
//import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


public class StripesMapper extends Mapper<LongWritable,Text,Text,MapWritable> {
	private MapWritable coOccurMap = new MapWritable();
	private Text word = new Text();
	private DoubleWritable val1 = new DoubleWritable(1);

	@Override
	//receives tweet in the value parameter
	protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
		//rejects all the tweets which don't contain hash
		if(!value.toString().contains("#"))	return ;	
		//rejects all the tweets which contains only hash
		if(value.toString().equals("#"))return;
		//splits the tweet with spaces and stores it in a word array
		String[] wordArr = value.toString().split("\\s+");	
		//checks if the array contains more than one #tag
		if (wordArr.length > 1) {
			for (int icount = 0; icount < wordArr.length; icount++) {
				if(wordArr[icount].length()>3){
				if(wordArr[icount].charAt(0)=='#'){
					word.set(wordArr[icount]);//sets the #tag to be considered for cooccurrence
					coOccurMap.clear();
					for (int jcount = icount+1; jcount < wordArr.length; jcount++) {
						if(wordArr[jcount].charAt(0)=='#'){
							if(wordArr[jcount].equals(wordArr[icount]))continue;
							Text keySearch = new Text(wordArr[jcount]);
							if(coOccurMap.containsKey(keySearch)){
								DoubleWritable valCount = (DoubleWritable)coOccurMap.get(keySearch);
								valCount.set(valCount.get()+1);
								coOccurMap.remove(keySearch);
								coOccurMap.put(keySearch, valCount);//writes the key in the map
							}
							else
								coOccurMap.put(keySearch,val1);
						}
					}
					context.write(word,coOccurMap);//writes the word and its map of occurrence in the context
				}
			}
		  }
		}
	}
}
