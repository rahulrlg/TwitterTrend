package stripes;

import java.io.IOException;
import java.util.Iterator;
import java.util.*;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Reducer;

//reducer that takes word and a map of its neighbour as an input
public class StripesReducer extends Reducer<Text, MapWritable, Text, Text> {
	private MapWritable tempMap = new MapWritable();
	@Override
	//Reducer that takes input key as a word and values as a map of words of its neighbour
	protected void reduce(Text key, Iterable<MapWritable> values, Context context) throws IOException, InterruptedException {
		tempMap.clear();
		//iterating over the whole map and puts all the keyset for a word in a list
		for (MapWritable value : values) {
			List<Writable> list = new ArrayList<Writable>();
			list.addAll(value.keySet());
			//iterator to iterate over the list of keys
			Iterator<Writable> itr = list.iterator();
			while(itr.hasNext()){
				Writable tempKey=itr.next();
				DoubleWritable originalCount = (DoubleWritable) value.get(tempKey);
				if (tempMap.containsKey(tempKey)) {
					//if key already present it adds the new value to the old one
					DoubleWritable countFromMap = (DoubleWritable) tempMap.get(tempKey);
					countFromMap.set(countFromMap.get() + originalCount.get());
				} else 
					tempMap.put(tempKey, originalCount);//if not present puts the value in the tempMap
			}
		}
		
		double totalCount=0.0;
		//list to contain all the keyset from the tempmap
		List<Writable> keyset = new ArrayList<Writable>();
		keyset.addAll(tempMap.keySet());
		//iterator to iterate over the keyset
		Iterator<Writable> itr = keyset.iterator();
		while(itr.hasNext()) {
			Writable tempkey2=itr.next();
			totalCount+=((DoubleWritable)tempMap.get(tempkey2)).get();
		}
		//iterator to iterate over the map
		String output="";
		Iterator<Map.Entry<Writable,Writable>> mapEntry;
		mapEntry = tempMap.entrySet().iterator();
		while(mapEntry.hasNext()){
			Map.Entry<Writable,Writable> pairs = (Map.Entry<Writable,Writable>) mapEntry.next();
			output=","+pairs.getKey()+":		"+(((DoubleWritable)pairs.getValue()).get()/totalCount);
			context.write(key, new Text(output));//puts the word pair and the relative frequency
		}
	}
}
