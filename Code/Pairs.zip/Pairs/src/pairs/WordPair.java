//taken reference from http://codingjunkie.net/cooccurrence/
package pairs;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class WordPair implements Writable,WritableComparable<WordPair> {

    private Text word;
    private Text neighbour;

    public WordPair(Text word, Text neighbour) {
        this.word = word;
        this.neighbour = neighbour;
    }

    public WordPair(String word, String neighbour) {
        this(new Text(word),new Text(neighbour));
    }

    public WordPair() {
        this.word = new Text();
        this.neighbour = new Text();
    }

    @Override
    public int compareTo(WordPair other) {
        int returnVal = this.word.compareTo(other.getWord());
        if(returnVal != 0){
            return returnVal;
        }
       if(this.neighbour.toString().equals("*")){
            return -1;
        }else if(other.getNeighbour().toString().equals("*")){
            return 1;
        }
        
        return this.neighbour.compareTo(other.getNeighbour());
    }

    public static WordPair read(DataInput in) throws IOException {
        WordPair wordPair = new WordPair();
        wordPair.readFields(in);
        return wordPair;
    }

    @Override
    public void write(DataOutput out) throws IOException {
        word.write(out);
        neighbour.write(out);
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        word.readFields(in);
        neighbour.readFields(in);
    }

    @Override
    public String toString() {
        return "{word=["+word+"]"+
               " neighbour=["+neighbour+"]}";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        WordPair wordPair = (WordPair) o;

        if (neighbour != null ? !neighbour.equals(wordPair.neighbour) : wordPair.neighbour != null) return false;
        if (word != null ? !word.equals(wordPair.word) : wordPair.word != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = word != null ? word.hashCode() : 0;
        result = 163 * result + (neighbour != null ? neighbour.hashCode() : 0);
        return result;
    }

    public void setWord(String word){
        this.word.set(word);
    }
    public void setNeighbour(String neighbour){
        this.neighbour.set(neighbour);
    }

    public Text getWord() {
        return word;
    }

    public Text getNeighbour() {
        return neighbour;
    }
}