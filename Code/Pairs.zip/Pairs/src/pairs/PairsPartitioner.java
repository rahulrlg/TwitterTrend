package pairs;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.mapreduce.Partitioner;

public class PairsPartitioner extends Partitioner<WordPair,DoubleWritable> {

	    @Override
	    public int getPartition(WordPair wordPair, DoubleWritable intWritable, int numPartitions) {
	        return Math.abs(wordPair.getWord().hashCode() % numPartitions);
	    }
	}
