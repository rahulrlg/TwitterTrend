package pairs;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class CoOccurrenceDriver {

	public static void main(String[] args) throws Exception {
		final int numReducers=2;
		String inputPath = "/testInput";
		String outputPath = "/myOutput";
		deleteFolder(new Configuration(), outputPath);

		Job job = Job.getInstance(new Configuration());
		job.setJarByClass(CoOccurrenceDriver.class);
		job.setMapperClass(PairsMapper.class);
		job.setPartitionerClass(PairsPartitioner.class);
		job.setReducerClass(PairsReducer.class);
		job.setMapOutputKeyClass(WordPair.class);
		job.setMapOutputValueClass(DoubleWritable.class);
		job.setOutputKeyClass(WordPair.class);
		job.setOutputValueClass(DoubleWritable.class);

		job.setNumReduceTasks(numReducers);
		
		FileInputFormat.addInputPath(job, new Path(inputPath));
		FileOutputFormat.setOutputPath(job, new Path(outputPath));
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}

	private static void deleteFolder(Configuration conf, String folderPath)
			throws IOException {
		FileSystem fs = FileSystem.get(conf);
		Path path = new Path(folderPath);
		if (fs.exists(path)) {
			fs.delete(path, true);
		}
	}

}
