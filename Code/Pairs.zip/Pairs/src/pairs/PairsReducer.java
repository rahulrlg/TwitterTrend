package pairs;
import java.io.IOException;
import java.util.*;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.mapreduce.Reducer;

public class PairsReducer extends Reducer<WordPair,DoubleWritable,WordPair,DoubleWritable> {
	static List<String> arr = new ArrayList<String>();
	DoubleWritable relFreq=new DoubleWritable();

	@Override
	//Reducer that takes input key as a word pair and count as value
	protected void reduce(WordPair key, Iterable<DoubleWritable> values, Context context) throws IOException, InterruptedException {
		int count = 0;
		//iterator to sum all the values corresponding to a word pair
		Iterator<DoubleWritable> itr = values.iterator();
		while (itr.hasNext()) {
			DoubleWritable value=itr.next();
			count += value.get();
		}
		//taking the total count for a particular word ie (word,"*")
		if(key.getNeighbour().toString().contains("*")){
			arr.add(key.getWord().toString()+"~"+count);
		}
		else{
			int totalPairCount=0;
			double calFreq;
			ListIterator<String> litr = arr.listIterator();
			while(litr.hasNext()){
				String str=litr.next();
				if(str.contains(key.getWord().toString())){
					String[] result = str.split("~");
					String indPairCount=result[1];
					//calculating totalcount for a particular word for all tweets
					totalPairCount+=Integer.parseInt(indPairCount);
				}
			}
			//calculating relative freq
			calFreq=count*1.0/totalPairCount;
			relFreq.set(calFreq);
			context.write(key,relFreq);
			totalPairCount=0;
		}
	}
}
