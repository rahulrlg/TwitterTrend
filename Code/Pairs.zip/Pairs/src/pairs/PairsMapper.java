package pairs;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import pairs.WordPair;
public class PairsMapper extends Mapper<Object, Text, WordPair, DoubleWritable> {

	private WordPair wordPair = new WordPair();
	private DoubleWritable val1 = new DoubleWritable(1);
	private DoubleWritable val2 = new DoubleWritable();
	int coOccurCount=0;
	//receives tweet in the value parameter
	public void map(Object key, Text value, Context context)throws IOException, InterruptedException {
		//rejects all the tweets which don't contain hash
		if(!value.toString().contains("#")){
		return ;	
		}
		//rejects all the tweets which contains only hash
		if(value.toString().equals("#")){
			return;
		}
		//splits the tweet with spaces and stores it in a word array
		String[] wordArr = value.toString().split("\\s+");	
		//checks if the array contains more than one #tag
		if (wordArr.length > 1) {
			for (int icount = 0; icount < wordArr.length; icount++) {
				if(wordArr[icount].charAt(0)=='#'){
					coOccurCount=0;	
					wordPair.setWord(wordArr[icount]);//sets the # to be considered for cooccurrence
					if(icount+1<wordArr.length){
						for(int jcount = icount+1;jcount < wordArr.length;jcount++){
							if(wordArr[jcount].charAt(0)=='#'){
								coOccurCount++;
								wordPair.setNeighbour(wordArr[jcount]);
								context.write(wordPair, val1);//writes the wordpair in the context
							}
						}	
					}
					if(coOccurCount==0)	continue;
					else{
						wordPair.setNeighbour("*");//adds the word with the total count of occurrence of that word
						val2.set(coOccurCount*1.0);
						context.write(wordPair,val2 );//writes the word pair in the context
					}
				}
			}
		}
	}
}
