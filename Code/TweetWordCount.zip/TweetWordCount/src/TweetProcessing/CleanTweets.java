package TweetProcessing;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CleanTweets {

	public static void main(String[] args) throws IOException {
		//file to collect all the tweets from local system
		FileReader inputFile = new FileReader("./data/tweets.txt");
		//file to collect the tweets after cleaning
		File outputFile = new File("./data/cleanFile.txt");	
		BufferedWriter bw = null;
		//create file if it doesn't exist
		if (!outputFile.exists()) {
			outputFile.createNewFile();
		}
		//reader that reads file line by line
		BufferedReader reader = new BufferedReader(inputFile);
		String line="";
		int i=0;
		while ((line=reader.readLine())!=null) {
			//cleaning all the tweets by passing the line one by one through various functions
			String cleanLine=rmvUsrIdFlwrCount(line);
			cleanLine=rmvhashDigits(cleanLine);
			cleanLine=rmvStopWord(cleanLine);
			cleanLine=rmvURL(cleanLine);
			cleanLine=rmvDigits(cleanLine);
			cleanLine=rmvSpaces(cleanLine);
			cleanLine=rmvSpecialChar(cleanLine);
			if(!cleanLine.equals("")){
				//writes the cleaned line into a new file
				FileWriter fw = new FileWriter(outputFile.getAbsoluteFile(),true);
				bw = new BufferedWriter(fw);
				bw.write(cleanLine+"\n");
				bw.close();
			}
		}		
	}
	
	public static String rmvUsrIdFlwrCount(String line) throws IOException{
		if(!line.contains("~"))return "";
		File usrIdFollowers = new File("./data/usrIdFollowers.txt");	
		BufferedWriter bw = null;
		if (!usrIdFollowers.exists()) {
			usrIdFollowers.createNewFile();
		}
		String cleanLine="";
		String[] array = line.split("~");
		if(array.length==2){
			FileWriter fw = new FileWriter(usrIdFollowers.getAbsoluteFile(),true);
			bw = new BufferedWriter(fw);
			//if(!array[1].equals(" "))
			bw.write(array[1]+"\n");	
			bw.close();
		}
		cleanLine=array[0];	
		return cleanLine;
	}
	//function to remove URL's from tweet reference:
	//http://stackoverflow.com/questions/12366496/removing-the-url-from-text-using-java
	public static String rmvURL(String line){
		String commentstr1=line;
        String urlPattern = "((https?|ftp|gopher|telnet|file|Unsure|http):((//)|(\\\\))+[\\w\\d:#@%/;$()~_?\\+-=\\\\\\.&]*)";
        Pattern p =Pattern.compile(urlPattern, Pattern.CASE_INSENSITIVE); 
        Matcher m = p.matcher(commentstr1);
        int i=0;
        while (m.find()) {
            commentstr1=commentstr1.replaceAll(m.group(i),"").trim();
            i++;
        }
        return commentstr1;
	}
	//removing digits from tweet
	public static String rmvDigits(String line) throws IOException{
		////system.out.println("in removing digits");
		String cleanLine="";
		String[] array = line.split(" ");
		for(int j=0;j<array.length;j++){
			//matcher to match any integer
			String commentstr1= array[j];
			String urlPattern = "^\\d+$";
	        Pattern p =Pattern.compile(urlPattern, Pattern.CASE_INSENSITIVE); 
	        Matcher m = p.matcher(commentstr1);
	        int i=0;
	        if(m.find()){}
	        else
	        {
				if(cleanLine.equals(""))
				cleanLine=array[j];
				else
					cleanLine=cleanLine+" "+array[j];
			}
		}
		return cleanLine;
	}
	//removing hash digits
	public static String rmvhashDigits(String line) throws IOException{
		String cleanLine="";
		String[] array = line.split(" ");
		for(int j=0;j<array.length;j++){
			String commentstr1= array[j];
			String urlPattern = "^#\\d+[a-z]*";
	        Pattern p =Pattern.compile(urlPattern, Pattern.CASE_INSENSITIVE); 
	        Matcher m = p.matcher(commentstr1);
	        int i=0;
	        if(m.find()){}
	        else
	        {
				if(cleanLine.equals(""))
				cleanLine=array[j];
				else
					cleanLine=cleanLine+" "+array[j];
			}
		}
		return cleanLine;
	}
	//removing unwanted spaces
	public static String rmvSpaces(String line) throws IOException{
		String cleanLine="";
		cleanLine=line.replaceAll("   ", " ");
		return cleanLine;
	}
	//removing special characters
	public static String rmvSpecialChar(String line) throws IOException{
		String cleanLine="";
		String[] array = line.split(" ");
		for(int j=0;j<array.length;j++){
			if(array[j].equals("+")||array[j].equals("-")||array[j].equals("?")||array[j].equals("\"")){
			}else{
				if(cleanLine.equals(""))
				cleanLine=array[j];
				else
					cleanLine=cleanLine+" "+array[j];
			}
		}
		return cleanLine;
	}
	//removing stop words
	public static String rmvStopWord(String line){
		//system.out.println("in rmvStopWord");
		String cleanLine="";
		String[] array = line.split(" ");
		for(int z=0;z<array.length;z++){
			if(array[z].equalsIgnoreCase("a")|| array[z].equalsIgnoreCase("able")
					|| array[z].equalsIgnoreCase("about") 
    			    || array[z].equalsIgnoreCase("above") 
    			    || array[z].equalsIgnoreCase("according") 
    			    || array[z].equalsIgnoreCase("accordingly") 
    			    || array[z].equalsIgnoreCase("across") 
    			    || array[z].equalsIgnoreCase("actually") 
    			    || array[z].equalsIgnoreCase("after") 
    			    || array[z].equalsIgnoreCase("afterwards") 
    			    || array[z].equalsIgnoreCase("again") 
    			    || array[z].equalsIgnoreCase("against") 
    			    || array[z].equalsIgnoreCase("all") 
    			    || array[z].equalsIgnoreCase("allow") 
    			    || array[z].equalsIgnoreCase("allows") 
    			    || array[z].equalsIgnoreCase("almost") 
    			    || array[z].equalsIgnoreCase("alone") 
    			    || array[z].equalsIgnoreCase("along") 
    			    || array[z].equalsIgnoreCase("already") 
    			    || array[z].equalsIgnoreCase("also") 
    			    || array[z].equalsIgnoreCase("although") 
    			    || array[z].equalsIgnoreCase("always") 
    			    || array[z].equalsIgnoreCase("am") 
    			    || array[z].equalsIgnoreCase("among") 
    			    || array[z].equalsIgnoreCase("amongst") 
    			    || array[z].equalsIgnoreCase("an") 
    			    || array[z].equalsIgnoreCase("and") 
    			    || array[z].equalsIgnoreCase("another") 
    			    || array[z].equalsIgnoreCase("any") 
    			    || array[z].equalsIgnoreCase("anybody") 
    			    || array[z].equalsIgnoreCase("anyhow") 
    			    || array[z].equalsIgnoreCase("anyone") 
    			    || array[z].equalsIgnoreCase("anything") 
    			    || array[z].equalsIgnoreCase("anyway") 
    			    || array[z].equalsIgnoreCase("anyways") 
    			    || array[z].equalsIgnoreCase("anywhere") 
    			    || array[z].equalsIgnoreCase("apart") 
    			    || array[z].equalsIgnoreCase("appear") 
    			    || array[z].equalsIgnoreCase("appreciate") 
    			    || array[z].equalsIgnoreCase("appropriate") 
    			    || array[z].equalsIgnoreCase("are") 
    			    || array[z].equalsIgnoreCase("around") 
    			    || array[z].equalsIgnoreCase("as") 
    			    || array[z].equalsIgnoreCase("aside") 
    			    || array[z].equalsIgnoreCase("ask") 
    			    || array[z].equalsIgnoreCase("asking") 
    			    || array[z].equalsIgnoreCase("associated") 
    			    || array[z].equalsIgnoreCase("at") 
    			    || array[z].equalsIgnoreCase("available") 
    			    || array[z].equalsIgnoreCase("away") 
    			    || array[z].equalsIgnoreCase("awfully") 
    			    || array[z].equalsIgnoreCase("b") 
    			    || array[z].equalsIgnoreCase("be") 
    			    || array[z].equalsIgnoreCase("became") 
    			    || array[z].equalsIgnoreCase("because") 
    			    || array[z].equalsIgnoreCase("become") 
    			    || array[z].equalsIgnoreCase("becomes") 
    			    || array[z].equalsIgnoreCase("becoming") 
    			    || array[z].equalsIgnoreCase("been") 
    			    || array[z].equalsIgnoreCase("before") 
    			    || array[z].equalsIgnoreCase("beforehand") 
    			    || array[z].equalsIgnoreCase("behind") 
    			    || array[z].equalsIgnoreCase("being") 
    			    || array[z].equalsIgnoreCase("believe") 
    			    || array[z].equalsIgnoreCase("below") 
    			    || array[z].equalsIgnoreCase("beside") 
    			    || array[z].equalsIgnoreCase("besides") 
    			    || array[z].equalsIgnoreCase("best") 
    			    || array[z].equalsIgnoreCase("better") 
    			    || array[z].equalsIgnoreCase("between") 
    			    || array[z].equalsIgnoreCase("beyond") 
    			    || array[z].equalsIgnoreCase("both") 
    			    || array[z].equalsIgnoreCase("brief") 
    			    || array[z].equalsIgnoreCase("but") 
    			    || array[z].equalsIgnoreCase("by") 
    			    || array[z].equalsIgnoreCase("c") 
    			    || array[z].equalsIgnoreCase("came") 
    			    || array[z].equalsIgnoreCase("can") 
    			    || array[z].equalsIgnoreCase("cannot") 
    			    || array[z].equalsIgnoreCase("cant") 
    			    || array[z].equalsIgnoreCase("cause") 
    			    || array[z].equalsIgnoreCase("causes") 
    			    || array[z].equalsIgnoreCase("certain") 
    			    || array[z].equalsIgnoreCase("certainly") 
    			    || array[z].equalsIgnoreCase("changes") 
    			    || array[z].equalsIgnoreCase("clearly") 
    			    || array[z].equalsIgnoreCase("co") 
    			    || array[z].equalsIgnoreCase("com") 
    			    || array[z].equalsIgnoreCase("come") 
    			    || array[z].equalsIgnoreCase("comes") 
    			    || array[z].equalsIgnoreCase("concerning") 
    			    || array[z].equalsIgnoreCase("consequently") 
    			    || array[z].equalsIgnoreCase("consider") 
    			    || array[z].equalsIgnoreCase("considering") 
    			    || array[z].equalsIgnoreCase("contain") 
    			    || array[z].equalsIgnoreCase("containing") 
    			    || array[z].equalsIgnoreCase("contains") 
    			    || array[z].equalsIgnoreCase("corresponding") 
    			    || array[z].equalsIgnoreCase("could") 
    			    || array[z].equalsIgnoreCase("course") 
    			    || array[z].equalsIgnoreCase("currently") 
    			    || array[z].equalsIgnoreCase("d") 
    			    || array[z].equalsIgnoreCase("definitely") 
    			    || array[z].equalsIgnoreCase("described") 
    			    || array[z].equalsIgnoreCase("despite") 
    			    || array[z].equalsIgnoreCase("did") 
    			    || array[z].equalsIgnoreCase("different") 
    			    || array[z].equalsIgnoreCase("do") 
    			    || array[z].equalsIgnoreCase("does") 
    			    || array[z].equalsIgnoreCase("doing") 
    			    || array[z].equalsIgnoreCase("done") 
    			    || array[z].equalsIgnoreCase("down") 
    			    || array[z].equalsIgnoreCase("downwards") 
    			    || array[z].equalsIgnoreCase("during") 
    			    || array[z].equalsIgnoreCase("e") 
    			    || array[z].equalsIgnoreCase("each") 
    			    || array[z].equalsIgnoreCase("edu") 
    			    || array[z].equalsIgnoreCase("eg") 
    			    || array[z].equalsIgnoreCase("either") 
    			    || array[z].equalsIgnoreCase("else") 
    			    || array[z].equalsIgnoreCase("elsewhere") 
    			    || array[z].equalsIgnoreCase("enough") 
    			    || array[z].equalsIgnoreCase("entirely") 
    			    || array[z].equalsIgnoreCase("especially") 
    			    || array[z].equalsIgnoreCase("et") 
    			    || array[z].equalsIgnoreCase("etc") 
    			    || array[z].equalsIgnoreCase("even") 
    			    || array[z].equalsIgnoreCase("ever") 
    			    || array[z].equalsIgnoreCase("every") 
    			    || array[z].equalsIgnoreCase("everybody") 
    			    || array[z].equalsIgnoreCase("everyone") 
    			    || array[z].equalsIgnoreCase("everything") 
    			    || array[z].equalsIgnoreCase("everywhere") 
    			    || array[z].equalsIgnoreCase("ex") 
    			    || array[z].equalsIgnoreCase("exactly") 
    			    || array[z].equalsIgnoreCase("example") 
    			    || array[z].equalsIgnoreCase("except") 
    			    || array[z].equalsIgnoreCase("f") 
    			    || array[z].equalsIgnoreCase("far") 
    			    || array[z].equalsIgnoreCase("few") 
    			    || array[z].equalsIgnoreCase("fifth") 
    			    || array[z].equalsIgnoreCase("first") 
    			    || array[z].equalsIgnoreCase("followed") 
    			    || array[z].equalsIgnoreCase("following") 
    			    || array[z].equalsIgnoreCase("follows") 
    			    || array[z].equalsIgnoreCase("for") 
    			    || array[z].equalsIgnoreCase("former") 
    			    || array[z].equalsIgnoreCase("formerly") 
    			    || array[z].equalsIgnoreCase("forth") 
    			    || array[z].equalsIgnoreCase("from") 
    			    || array[z].equalsIgnoreCase("further") 
    			    || array[z].equalsIgnoreCase("furthermore") 
    			    || array[z].equalsIgnoreCase("g") 
    			    || array[z].equalsIgnoreCase("get") 
    			    || array[z].equalsIgnoreCase("gets") 
    			    || array[z].equalsIgnoreCase("getting") 
    			    || array[z].equalsIgnoreCase("given") 
    			    || array[z].equalsIgnoreCase("gives") 
    			    || array[z].equalsIgnoreCase("go") 
    			    || array[z].equalsIgnoreCase("goes") 
    			    || array[z].equalsIgnoreCase("going") 
    			    || array[z].equalsIgnoreCase("gone") 
    			    || array[z].equalsIgnoreCase("got") 
    			    || array[z].equalsIgnoreCase("gotten") 
    			    || array[z].equalsIgnoreCase("greetings") 
    			    || array[z].equalsIgnoreCase("h") 
    			    || array[z].equalsIgnoreCase("had") 
    			    || array[z].equalsIgnoreCase("happens") 
    			    || array[z].equalsIgnoreCase("hardly") 
    			    || array[z].equalsIgnoreCase("has") 
    			    || array[z].equalsIgnoreCase("have") 
    			    || array[z].equalsIgnoreCase("having") 
    			    || array[z].equalsIgnoreCase("he") 
    			    || array[z].equalsIgnoreCase("hello") 
    			    || array[z].equalsIgnoreCase("help") 
    			    || array[z].equalsIgnoreCase("hence") 
    			    || array[z].equalsIgnoreCase("her") 
    			    || array[z].equalsIgnoreCase("here") 
    			    || array[z].equalsIgnoreCase("hereafter") 
    			    || array[z].equalsIgnoreCase("hereby") 
    			    || array[z].equalsIgnoreCase("herein") 
    			    || array[z].equalsIgnoreCase("hereupon") 
    			    || array[z].equalsIgnoreCase("hers") 
    			    || array[z].equalsIgnoreCase("herself") 
    			    || array[z].equalsIgnoreCase("hi") 
    			    || array[z].equalsIgnoreCase("him") 
    			    || array[z].equalsIgnoreCase("himself") 
    			    || array[z].equalsIgnoreCase("his") 
    			    || array[z].equalsIgnoreCase("hither") 
    			    || array[z].equalsIgnoreCase("hopefully") 
    			    || array[z].equalsIgnoreCase("how") 
    			    || array[z].equalsIgnoreCase("howbeit") 
    			    || array[z].equalsIgnoreCase("however") 
    			    || array[z].equalsIgnoreCase("i") 
    			    || array[z].equalsIgnoreCase("ie") 
    			    || array[z].equalsIgnoreCase("if") 
    			    || array[z].equalsIgnoreCase("ignored") 
    			    || array[z].equalsIgnoreCase("immediate") 
    			    || array[z].equalsIgnoreCase("in") 
    			    || array[z].equalsIgnoreCase("inasmuch") 
    			    || array[z].equalsIgnoreCase("inc") 
    			    || array[z].equalsIgnoreCase("indeed") 
    			    || array[z].equalsIgnoreCase("indicate") 
    			    || array[z].equalsIgnoreCase("indicated") 
    			    || array[z].equalsIgnoreCase("indicates") 
    			    || array[z].equalsIgnoreCase("inner") 
    			    || array[z].equalsIgnoreCase("insofar") 
    			    || array[z].equalsIgnoreCase("instead") 
    			    || array[z].equalsIgnoreCase("into") 
    			    || array[z].equalsIgnoreCase("inward") 
    			    || array[z].equalsIgnoreCase("is") 
    			    || array[z].equalsIgnoreCase("it") 
    			    || array[z].equalsIgnoreCase("its") 
    			    || array[z].equalsIgnoreCase("itself") 
    			    || array[z].equalsIgnoreCase("j") 
    			    || array[z].equalsIgnoreCase("just") 
    			    || array[z].equalsIgnoreCase("k") 
    			    || array[z].equalsIgnoreCase("keep") 
    			    || array[z].equalsIgnoreCase("keeps") 
    			    || array[z].equalsIgnoreCase("kept") 
    			    || array[z].equalsIgnoreCase("know") 
    			    || array[z].equalsIgnoreCase("knows") 
    			    || array[z].equalsIgnoreCase("known") 
    			    || array[z].equalsIgnoreCase("l") 
    			    || array[z].equalsIgnoreCase("last") 
    			    || array[z].equalsIgnoreCase("lately") 
    			    || array[z].equalsIgnoreCase("later") 
    			    || array[z].equalsIgnoreCase("latter") 
    			    || array[z].equalsIgnoreCase("latterly") 
    			    || array[z].equalsIgnoreCase("least") 
    			    || array[z].equalsIgnoreCase("less") 
    			    || array[z].equalsIgnoreCase("lest") 
    			    || array[z].equalsIgnoreCase("let") 
    			    || array[z].equalsIgnoreCase("like") 
    			    || array[z].equalsIgnoreCase("liked") 
    			    || array[z].equalsIgnoreCase("likely") 
    			    || array[z].equalsIgnoreCase("little") 
    			    || array[z].equalsIgnoreCase("ll")
    			    || array[z].equalsIgnoreCase("look") 
    			    || array[z].equalsIgnoreCase("looking") 
    			    || array[z].equalsIgnoreCase("looks") 
    			    || array[z].equalsIgnoreCase("ltd") 
    			    || array[z].equalsIgnoreCase("m") 
    			    || array[z].equalsIgnoreCase("mainly") 
    			    || array[z].equalsIgnoreCase("many") 
    			    || array[z].equalsIgnoreCase("may") 
    			    || array[z].equalsIgnoreCase("maybe") 
    			    || array[z].equalsIgnoreCase("me") 
    			    || array[z].equalsIgnoreCase("mean") 
    			    || array[z].equalsIgnoreCase("meanwhile") 
    			    || array[z].equalsIgnoreCase("merely") 
    			    || array[z].equalsIgnoreCase("might") 
    			    || array[z].equalsIgnoreCase("more") 
    			    || array[z].equalsIgnoreCase("moreover") 
    			    || array[z].equalsIgnoreCase("most") 
    			    || array[z].equalsIgnoreCase("mostly") 
    			    || array[z].equalsIgnoreCase("much") 
    			    || array[z].equalsIgnoreCase("must") 
    			    || array[z].equalsIgnoreCase("my") 
    			    || array[z].equalsIgnoreCase("myself") 
    			    || array[z].equalsIgnoreCase("n") 
    			    || array[z].equalsIgnoreCase("name") 
    			    || array[z].equalsIgnoreCase("namely") 
    			    || array[z].equalsIgnoreCase("nd") 
    			    || array[z].equalsIgnoreCase("near") 
    			    || array[z].equalsIgnoreCase("nearly") 
    			    || array[z].equalsIgnoreCase("necessary") 
    			    || array[z].equalsIgnoreCase("need") 
    			    || array[z].equalsIgnoreCase("needs") 
    			    || array[z].equalsIgnoreCase("neither") 
    			    || array[z].equalsIgnoreCase("never") 
    			    || array[z].equalsIgnoreCase("nevertheless") 
    			    || array[z].equalsIgnoreCase("new") 
    			    || array[z].equalsIgnoreCase("next") 
    			    || array[z].equalsIgnoreCase("no") 
    			    || array[z].equalsIgnoreCase("nobody") 
    			    || array[z].equalsIgnoreCase("non") 
    			    || array[z].equalsIgnoreCase("none") 
    			    || array[z].equalsIgnoreCase("noone") 
    			    || array[z].equalsIgnoreCase("nor") 
    			    || array[z].equalsIgnoreCase("normally") 
    			    || array[z].equalsIgnoreCase("not") 
    			    || array[z].equalsIgnoreCase("nothing") 
    			    || array[z].equalsIgnoreCase("novel") 
    			    || array[z].equalsIgnoreCase("now") 
    			    || array[z].equalsIgnoreCase("nowhere") 
    			    || array[z].equalsIgnoreCase("o") 
    			    || array[z].equalsIgnoreCase("obviously") 
    			    || array[z].equalsIgnoreCase("of") 
    			    || array[z].equalsIgnoreCase("off") 
    			    || array[z].equalsIgnoreCase("often") 
    			    || array[z].equalsIgnoreCase("oh") 
    			    || array[z].equalsIgnoreCase("ok") 
    			    || array[z].equalsIgnoreCase("okay") 
    			    || array[z].equalsIgnoreCase("old") 
    			    || array[z].equalsIgnoreCase("on") 
    			    || array[z].equalsIgnoreCase("once") 
    			    || array[z].equalsIgnoreCase("ones") 
    			    || array[z].equalsIgnoreCase("only") 
    			    || array[z].equalsIgnoreCase("onto") 
    			    || array[z].equalsIgnoreCase("or") 
    			    || array[z].equalsIgnoreCase("other") 
    			    || array[z].equalsIgnoreCase("others") 
    			    || array[z].equalsIgnoreCase("otherwise") 
    			    || array[z].equalsIgnoreCase("ought") 
    			    || array[z].equalsIgnoreCase("our") 
    			    || array[z].equalsIgnoreCase("ours") 
    			    || array[z].equalsIgnoreCase("ourselves") 
    			    || array[z].equalsIgnoreCase("out") 
    			    || array[z].equalsIgnoreCase("outside") 
    			    || array[z].equalsIgnoreCase("over") 
    			    || array[z].equalsIgnoreCase("overall") 
    			    || array[z].equalsIgnoreCase("own") 
    			    || array[z].equalsIgnoreCase("p") 
    			    || array[z].equalsIgnoreCase("particular") 
    			    || array[z].equalsIgnoreCase("particularly") 
    			    || array[z].equalsIgnoreCase("per") 
    			    || array[z].equalsIgnoreCase("perhaps") 
    			    || array[z].equalsIgnoreCase("placed") 
    			    || array[z].equalsIgnoreCase("please") 
    			    || array[z].equalsIgnoreCase("plus") 
    			    || array[z].equalsIgnoreCase("possible") 
    			    || array[z].equalsIgnoreCase("presumably") 
    			    || array[z].equalsIgnoreCase("probably") 
    			    || array[z].equalsIgnoreCase("provides") 
    			    || array[z].equalsIgnoreCase("q") 
    			    || array[z].equalsIgnoreCase("que") 
    			    || array[z].equalsIgnoreCase("quite") 
    			    || array[z].equalsIgnoreCase("qv") 
    			    || array[z].equalsIgnoreCase("r") 
    			    || array[z].equalsIgnoreCase("rather") 
    			    || array[z].equalsIgnoreCase("rd") 
    			    || array[z].equalsIgnoreCase("re") 
    			    || array[z].equalsIgnoreCase("really") 
    			    || array[z].equalsIgnoreCase("reasonably") 
    			    || array[z].equalsIgnoreCase("regarding") 
    			    || array[z].equalsIgnoreCase("regardless") 
    			    || array[z].equalsIgnoreCase("regards") 
    			    || array[z].equalsIgnoreCase("relatively") 
    			    || array[z].equalsIgnoreCase("respectively") 
    			    || array[z].equalsIgnoreCase("right") 
    			    || array[z].equalsIgnoreCase("s") 
    			    || array[z].equalsIgnoreCase("said") 
    			    || array[z].equalsIgnoreCase("same") 
    			    || array[z].equalsIgnoreCase("saw") 
    			    || array[z].equalsIgnoreCase("say") 
    			    || array[z].equalsIgnoreCase("saying") 
    			    || array[z].equalsIgnoreCase("says") 
    			    || array[z].equalsIgnoreCase("second") 
    			    || array[z].equalsIgnoreCase("secondly") 
    			    || array[z].equalsIgnoreCase("see") 
    			    || array[z].equalsIgnoreCase("seeing") 
    			    || array[z].equalsIgnoreCase("seem") 
    			    || array[z].equalsIgnoreCase("seemed") 
    			    || array[z].equalsIgnoreCase("seeming") 
    			    || array[z].equalsIgnoreCase("seems") 
    			    || array[z].equalsIgnoreCase("seen") 
    			    || array[z].equalsIgnoreCase("self") 
    			    || array[z].equalsIgnoreCase("selves") 
    			    || array[z].equalsIgnoreCase("sensible") 
    			    || array[z].equalsIgnoreCase("sent") 
    			    || array[z].equalsIgnoreCase("serious") 
    			    || array[z].equalsIgnoreCase("seriously") 
    			    || array[z].equalsIgnoreCase("several") 
    			    || array[z].equalsIgnoreCase("shall") 
    			    || array[z].equalsIgnoreCase("she") 
    			    || array[z].equalsIgnoreCase("should") 
    			    || array[z].equalsIgnoreCase("since") 
    			    || array[z].equalsIgnoreCase("so") 
    			    || array[z].equalsIgnoreCase("some") 
    			    || array[z].equalsIgnoreCase("somebody") 
    			    || array[z].equalsIgnoreCase("somehow") 
    			    || array[z].equalsIgnoreCase("someone") 
    			    || array[z].equalsIgnoreCase("something") 
    			    || array[z].equalsIgnoreCase("sometime") 
    			    || array[z].equalsIgnoreCase("sometimes") 
    			    || array[z].equalsIgnoreCase("somewhat") 
    			    || array[z].equalsIgnoreCase("somewhere") 
    			    || array[z].equalsIgnoreCase("soon") 
    			    || array[z].equalsIgnoreCase("sorry") 
    			    || array[z].equalsIgnoreCase("specified") 
    			    || array[z].equalsIgnoreCase("specify") 
    			    || array[z].equalsIgnoreCase("specifying") 
    			    || array[z].equalsIgnoreCase("still") 
    			    || array[z].equalsIgnoreCase("sub") 
    			    || array[z].equalsIgnoreCase("such") 
    			    || array[z].equalsIgnoreCase("sup") 
    			    || array[z].equalsIgnoreCase("sure") 
    			    || array[z].equalsIgnoreCase("t") 
    			    || array[z].equalsIgnoreCase("take") 
    			    || array[z].equalsIgnoreCase("taken") 
    			    || array[z].equalsIgnoreCase("tell") 
    			    || array[z].equalsIgnoreCase("tends") 
    			    || array[z].equalsIgnoreCase("th") 
    			    || array[z].equalsIgnoreCase("than") 
    			    || array[z].equalsIgnoreCase("thank") 
    			    || array[z].equalsIgnoreCase("thanks") 
    			    || array[z].equalsIgnoreCase("thanx") 
    			    || array[z].equalsIgnoreCase("that") 
    			    || array[z].equalsIgnoreCase("thats") 
    			    || array[z].equalsIgnoreCase("the") 
    			    || array[z].equalsIgnoreCase("their") 
    			    || array[z].equalsIgnoreCase("theirs") 
    			    || array[z].equalsIgnoreCase("them") 
    			    || array[z].equalsIgnoreCase("themselves") 
    			    || array[z].equalsIgnoreCase("then") 
    			    || array[z].equalsIgnoreCase("thence") 
    			    || array[z].equalsIgnoreCase("there") 
    			    || array[z].equalsIgnoreCase("thereafter") 
    			    || array[z].equalsIgnoreCase("thereby") 
    			    || array[z].equalsIgnoreCase("therefore") 
    			    || array[z].equalsIgnoreCase("therein") 
    			    || array[z].equalsIgnoreCase("theres") 
    			    || array[z].equalsIgnoreCase("thereupon") 
    			    || array[z].equalsIgnoreCase("these") 
    			    || array[z].equalsIgnoreCase("they") 
    			    || array[z].equalsIgnoreCase("think") 
    			    || array[z].equalsIgnoreCase("third") 
    			    || array[z].equalsIgnoreCase("this") 
    			    || array[z].equalsIgnoreCase("thorough") 
    			    || array[z].equalsIgnoreCase("thoroughly") 
    			    || array[z].equalsIgnoreCase("those") 
    			    || array[z].equalsIgnoreCase("though") 
    			    || array[z].equalsIgnoreCase("through") 
    			    || array[z].equalsIgnoreCase("throughout") 
    			    || array[z].equalsIgnoreCase("thru") 
    			    || array[z].equalsIgnoreCase("thus") 
    			    || array[z].equalsIgnoreCase("to") 
    			    || array[z].equalsIgnoreCase("together") 
    			    || array[z].equalsIgnoreCase("too") 
    			    || array[z].equalsIgnoreCase("took") 
    			    || array[z].equalsIgnoreCase("toward") 
    			    || array[z].equalsIgnoreCase("towards") 
    			    || array[z].equalsIgnoreCase("tried") 
    			    || array[z].equalsIgnoreCase("tries") 
    			    || array[z].equalsIgnoreCase("truly") 
    			    || array[z].equalsIgnoreCase("try") 
    			    || array[z].equalsIgnoreCase("trying") 
    			    || array[z].equalsIgnoreCase("twice") 
    			    || array[z].equalsIgnoreCase("u") 
    			    || array[z].equalsIgnoreCase("un") 
    			    || array[z].equalsIgnoreCase("under") 
    			    || array[z].equalsIgnoreCase("unfortunately") 
    			    || array[z].equalsIgnoreCase("unless") 
    			    || array[z].equalsIgnoreCase("unlikely") 
    			    || array[z].equalsIgnoreCase("until") 
    			    || array[z].equalsIgnoreCase("unto") 
    			    || array[z].equalsIgnoreCase("up") 
    			    || array[z].equalsIgnoreCase("upon") 
    			    || array[z].equalsIgnoreCase("us") 
    			    || array[z].equalsIgnoreCase("use") 
    			    || array[z].equalsIgnoreCase("used") 
    			    || array[z].equalsIgnoreCase("useful") 
    			    || array[z].equalsIgnoreCase("uses") 
    			    || array[z].equalsIgnoreCase("using") 
    			    || array[z].equalsIgnoreCase("usually") 
    			    || array[z].equalsIgnoreCase("uucp") 
    			    || array[z].equalsIgnoreCase("v") 
    			    || array[z].equalsIgnoreCase("value") 
    			    || array[z].equalsIgnoreCase("various") 
    			    || array[z].equalsIgnoreCase("you've") 
    			    || array[z].equalsIgnoreCase("very") 
    			    || array[z].equalsIgnoreCase("via") 
    			    || array[z].equalsIgnoreCase("viz") 
    			    || array[z].equalsIgnoreCase("vs") 
    			    || array[z].equalsIgnoreCase("w") 
    			    || array[z].equalsIgnoreCase("want") 
    			    || array[z].equalsIgnoreCase("wants") 
    			    || array[z].equalsIgnoreCase("http")
    			    || array[z].equalsIgnoreCase("https")
    			    || array[z].equalsIgnoreCase("http:")
    			    || array[z].equalsIgnoreCase("https:")
    			    || array[z].equalsIgnoreCase("was") 
    			    || array[z].equalsIgnoreCase("way") 
    			    || array[z].equalsIgnoreCase("we") 
    			    || array[z].equalsIgnoreCase("welcome") 
    			    || array[z].equalsIgnoreCase("well") 
    			    || array[z].equalsIgnoreCase("went") 
    			    || array[z].equalsIgnoreCase("were") 
    			    || array[z].equalsIgnoreCase("what") 
    			    || array[z].equalsIgnoreCase("whatever")
    			    || array[z].contains("//")
    			    || array[z].equalsIgnoreCase("when") 
    			    || array[z].equalsIgnoreCase("whence") 
    			    || array[z].equalsIgnoreCase("whenever") 
    			    || array[z].equalsIgnoreCase("where") 
    			    || array[z].equalsIgnoreCase("whereafter") 
    			    || array[z].equalsIgnoreCase("whereas") 
    			    || array[z].equalsIgnoreCase("whereby") 
    			    || array[z].equalsIgnoreCase("wherein") 
    			    || array[z].equalsIgnoreCase("whereupon") 
    			    || array[z].equalsIgnoreCase("wherever") 
    			    || array[z].equalsIgnoreCase("whether") 
    			    || array[z].equalsIgnoreCase("which") 
    			    || array[z].equalsIgnoreCase("while") 
    			    || array[z].equalsIgnoreCase("whither") 
    			    || array[z].equalsIgnoreCase("who") 
    			    || array[z].equalsIgnoreCase("whoever") 
    			    || array[z].equalsIgnoreCase("whole") 
    			    || array[z].equalsIgnoreCase("whom") 
    			    || array[z].equalsIgnoreCase("whose") 
    			    || array[z].equalsIgnoreCase("why") 
    			    || array[z].equalsIgnoreCase("will") 
    			    || array[z].equalsIgnoreCase("willing") 
    			    || array[z].equalsIgnoreCase("wish") 
    			    || array[z].equalsIgnoreCase("with") 
    			    || array[z].equalsIgnoreCase("within") 
    			    || array[z].equalsIgnoreCase("without") 
    			    || array[z].equalsIgnoreCase("wonder") 
    			    || array[z].equalsIgnoreCase("would") 
    			    || array[z].equalsIgnoreCase("would") 
    			    || array[z].equalsIgnoreCase("x") 
    			    || array[z].equalsIgnoreCase("y") 
    			    || array[z].equalsIgnoreCase("yes") 
    			    || array[z].equalsIgnoreCase("yet") 
    			    || array[z].equalsIgnoreCase("you")
    			    || array[z].equalsIgnoreCase("you'll") 
    			    || array[z].equalsIgnoreCase("your") 
    			    || array[z].equalsIgnoreCase("yours") 
    			    || array[z].equalsIgnoreCase("yourself") 
    			    || array[z].equalsIgnoreCase("yourselves") 
    			    || array[z].equalsIgnoreCase("z") 
    			    || array[z].equalsIgnoreCase("RT")
    			    || array[z].equalsIgnoreCase("I'm")
    			    || array[z].equalsIgnoreCase("guys")
    			    || array[z].equalsIgnoreCase("This")
    			    || array[z].equalsIgnoreCase("I'm")
    			    || array[z].equalsIgnoreCase("I")
    			    || array[z].equalsIgnoreCase("!")
    			    || array[z].equalsIgnoreCase("chicks")
    			    || array[z].equalsIgnoreCase("compare")
    			){
			}else{
				if(cleanLine.equals(""))
				cleanLine=array[z];
				else
					cleanLine=cleanLine+" "+array[z];
			}
		}
		return cleanLine;
	}
}
